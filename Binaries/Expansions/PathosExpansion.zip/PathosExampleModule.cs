﻿using System;
using System.Text;
using System.Linq;
using Inv.Support;

namespace Pathos
{
  internal sealed class ExampleModule : Module
  {
    internal ExampleModule(Codex Codex)
      : base(Handle: "Example", Name: "Example Adventure", Description: "Starting point for designing your own adventure.", Colour: Inv.Colour.DarkViolet, Author: "Callan Hodgskin", Email: "hodgskin.callan@gmail.com", RequiresMasterMode: false, IsPublished: true)
    {
      this.Codex = Codex;
      SetTrack(Codex.Tracks.outside);
    }

    public override void Execute(Generator Generator)
    {
      var Adventure = Generator.Adventure;

      var MainSite = Adventure.World.AddSite("Main");

      var MainMap = Adventure.World.AddMap("Main", Width: 100, Height: 100);
      MainMap.SetAtmosphere(Codex.Atmospheres.dungeon);
      MainMap.SetTerminal(true);

      var StartSquare = MainMap[50, 50];

      var MainLevel = MainSite.AddLevel(1, MainMap);
      MainLevel.SetTransitions(StartSquare, null);

      var StartRegion = new Region(46, 46, 54, 54);

      var StartZone = MainMap.AddZone();
      StartZone.AddRegion(StartRegion);
      StartZone.SetLit(true);

      Generator.PlaceRoom(MainMap, Codex.Barriers.stone_wall, Codex.Grounds.stone_floor, StartRegion);
      Generator.PlacePassage(StartSquare, Codex.Portals.stone_staircase_up, Destination: null);

      Adventure.World.SetStart(StartSquare);
    }

    private readonly Codex Codex;
  }
}
