﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Inv.Support;

namespace Pathos
{
  internal sealed class ExampleExpansion : Expansion
  {
    internal ExampleExpansion(OfficialCampaign Campaign)
      : base(Campaign, "example", "Example")
    {
      var Items = Campaign.Codex.Items;
      var Attributes = Campaign.Codex.Attributes;
      var Elements = Campaign.Codex.Elements;
      var Properties = Campaign.Codex.Properties;
      var Skills = Campaign.Codex.Skills;
      var Qualifications = Campaign.Codex.Qualifications;
      var Genders = Campaign.Codex.Genders;

      var MaleDeveloperGlyph = Campaign.Codex.Glyphs.Add("male developer");
      var FemaleDeveloperGlyph = Campaign.Codex.Glyphs.Add("female developer");

      var DeveloperClass = Campaign.Codex.Classes.Add(C =>
      {
        C.Name = "developer";
        C.Description = "Idiot C# programmer.";
        C.Backpack = Items.Backpack;
        C.LifeAdvancement.Set(14, 1.d10());
        C.ManaAdvancement.Set(1, Dice.Fixed(1));
        C.SetDistribution(Attributes.intelligence, Attributes.dexterity, Attributes.wisdom, Attributes.constitution, Attributes.charisma, Attributes.strength);
        C.AddAvatar(Genders.male, MaleDeveloperGlyph);
        C.AddAvatar(Genders.female, FemaleDeveloperGlyph);
        C.AddFeat(4, Elements.poison);
        C.AddFeat(8, Properties.appraisal);
        C.AddFeat(12, Properties.stealth);
        C.Startup.SetSkill(Qualifications.proficient,
          Skills.literacy,
          Skills.evocation,
          Skills.light_armour,
          Skills.light_blade,
          Skills.club);
        C.Startup.Loot.AddKit(Chance.Always, Modifier.Plus5, Items.club);
        C.Startup.Loot.AddKit(Chance.Always, Items.sandwich);
      });

      Campaign.AddModule(new ExampleModule(Campaign.Codex));
    }
  }
}