#pragma warning disable 0649
namespace Pathos
{
  internal static class Resources
  {
    static Resources()
    {
      global::Inv.Resource.Foundation.Import(typeof(Resources), "Resources.Pathos.InvResourcePackage.rs");
    }

  }
}