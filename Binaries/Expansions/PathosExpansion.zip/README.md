# Pathos Exapnsion API

Pathos can be expanded with custom content definitions and module generation algorithms, written in C#. You can develop and debug your content and modules using Visual Studio, with full IDE support. Your expansions can be shared and played on Windows and Android.

The full source code for the official content and modules are published in the following GitHub repository:

<https://github.com/callanh/pathos-official>

Use this reposistory as a reference when developing your own expansion.

> Note that games played on custom modules are visible in the Hall of Fame.

## Quick Start

### Prerequisites

* Microsoft Windows
* [Visual Studio 2022](https://visualstudio.microsoft.com/downloads/) - note that Community edition is free.
* [Pathos for Windows Desktop](https://pathos.azurewebsites.net/) - install to the default folder `C:\Games\Pathos`

Make sure you run Pathos to make sure it has self-updated to the latest version. Pathos for Windows Desktop is updated regularly.

### Development

1. Unzip the file `C:\Games\Pathos\Expansions\PathosExpansion.zip` into the same folder.
2. Open the solution file `C:\Games\Pathos\Expansions\PathosExpansion.sln` in Visual Studio 2022.
3. Run the `PathosExpansion` project which will launch `C:\Games\Pathos\PathosGame.exe` in the context of the just built expansion.
4. Select a hero to start a new game in the `Example Adventure` module.
5. Quit the app to return to Visual Studio.
6. Make a change in `PathosExampleModule.cs` and run again to see the difference.

### Variables

In Visual Studio, double click the `PathosExpansion` project and look for the following section in the file:

```xml
<PropertyGroup>
  <PathosInstallation>C:\Games\Pathos</PathosInstallation>
</PropertyGroup>
```

These variables can be modified to select the installation folder as well as which quest and hero to use when debugging.

## Build and Release

Pathos loads custom expansions from `C:\Games\Pathos\Expansions` and they must also have the extension of `Expansion.dll`. It is recommended to deploy the `Expansion.pdb` file as well. PDB files carry useful debugging information such as line numbers for any exception stack traces.

When building, the custom expansion will be compiled in both `net48` and `netstandard20`. They are separate subfolders in the `bin` folder. Below are examples of the release paths:

```bat
PathosExpansion\bin\Release\net48\PathosExpansion.dll
PathosExpansion\bin\Release\net48\PathosExpansion.pdb
PathosExpansion\bin\Release\netstandard20\PathosExpansion.dll
PathosExpansion\bin\Release\netstandard20\PathosExpansion.pdb
```

When building RELEASE, the `net48` files will be automatically deployed to the `C:\Games\Pathos\Expansions` folder using a post-build event.

To release to Android, manually upload the `netstandard20` assembly files to your Cloud storage such as Google Drive. Inside the Pathos Android app, use the Diagnostics screen to import these files. The Pathos app will need to be restarted to load these new expansions.

## Platforms

Not all platforms can support loading of custom expansions. The current state is listed below:

* **Windows Desktop** supports loading `net48` assemblies at runtime.

* **Android** supports loading `netstandard20` assemblies at runtime.

* **iOS** _does not_ support loading any assemblies at runtime. Even if it were technically possible, it's unlikely that Apple would approve an app that could dynamically load assemblies that had not gone through the App Review Process. Below is the error when attempting to load an assembly on iOS:

  > `Failed to load AOT expansion '/private/var/mobile/Containers/Data/Application/2157DE21-9F96-44FE-94A3-3827C4257A02/Library/Expansions/PathosExpansion.dll.so' in aot-only mode.`

* **UWP** _does not_ support loading any assemblies at runtime which means Windows Store and Xbox versions cannot run custom expansions. This appears to be a security decision by Microsoft, similar to the Apple rationale. Below is the exception when attempting to load an assembly on UWP:

  > `Assembly.LoadFile is not supported in AppX`

Custom expansions can be delivered to iOS and UWP if they are compiled and redistributed as an 'official' expansion. That is, if you have developed an amazing custom expansion and wish to contribute the source code to the Pathos project, please contact me.

## Caveats

* The Hall of Fame relies on having unique module handles. To avoid accidental collisions with another developer, choose a good module handle.
* The Pathos API only has minimal summarydoc (.xml) so please hit me up with any documentation requests.
* Custom expansions are not guaranteed to be safe as they contain compiled C# code and could be compromised. Use a virus scanner and only install custom expansions from trusted sources. Developers are encouraged to use open source licensing to share their custom expansions which provides more safety to the players.

## Starting from scratch

If you are confident in Visual Studio and C#, you may prefer to start your solution from scratch. The Pathos API can be accessed by referencing the released assemblies.

Important assembly references:

* `Inv.Library.dll` for useful extensions to the .NET framework.
* `PathosLibrary.dll` for shared classes and extension methods.
* `PathosEngine.dll` for the Manifest and Generator classes.
* `PathosOfficial.dll` for the official campaign, modules and content.

Create a new class with base type `Pathos.Expansion` class and implement the public constructor with a single parameter of type `Pathos.OfficialCampaign`.

Launch with the command line argument:

`C:\Games\Pathos\Pathos.exe disable-update expansion:C:\Projects\MyPathos\bin\Debug\net48\MyPathosExpansion.dll`
